--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9
-- Dumped by pg_dump version 16.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: check_order_invariants(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_order_invariants(p_order_id uuid) RETURNS TABLE(invariant character varying, passed boolean, details text)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_order RECORD;
    v_completed_qty INTEGER;
    v_failed_qty INTEGER;
    v_active_count INTEGER;
BEGIN
    SELECT * INTO v_order FROM orders WHERE id = p_order_id;
    
    IF NOT FOUND THEN
        RETURN QUERY SELECT 'ORDER_NOT_FOUND'::VARCHAR, FALSE, 'Order does not exist'::TEXT;
        RETURN;
    END IF;
    
    IF COALESCE(v_order.uses_task_delivery, FALSE) THEN
        -- INV-1: Quantity accounting
        SELECT COALESCE(SUM(quantity), 0) INTO v_completed_qty
        FROM order_tasks WHERE order_id = p_order_id AND status = 'COMPLETED';
        
        SELECT COALESCE(SUM(quantity), 0) INTO v_failed_qty
        FROM order_tasks WHERE order_id = p_order_id AND status = 'FAILED_PERMANENT';
        
        IF v_order.status = 'COMPLETED' THEN
            IF (v_completed_qty + v_failed_qty) = v_order.quantity THEN
                RETURN QUERY SELECT 'INV-1'::VARCHAR, TRUE, 
                    format('Qty accounted: %s completed + %s failed = %s', v_completed_qty, v_failed_qty, v_order.quantity);
            ELSE
                RETURN QUERY SELECT 'INV-1'::VARCHAR, FALSE, 
                    format('Qty mismatch: %s completed + %s failed = %s, expected %s', 
                        v_completed_qty, v_failed_qty, v_completed_qty + v_failed_qty, v_order.quantity);
            END IF;
        ELSE
            RETURN QUERY SELECT 'INV-1'::VARCHAR, TRUE, 'Order not COMPLETED yet, skipping accounting check';
        END IF;
        
        -- INV-3: No active tasks for COMPLETED order
        IF v_order.status = 'COMPLETED' THEN
            SELECT COUNT(*) INTO v_active_count
            FROM order_tasks 
            WHERE order_id = p_order_id 
            AND status NOT IN ('COMPLETED', 'FAILED_PERMANENT');
            
            IF v_active_count = 0 THEN
                RETURN QUERY SELECT 'INV-3'::VARCHAR, TRUE, 'All tasks terminal';
            ELSE
                RETURN QUERY SELECT 'INV-3'::VARCHAR, FALSE, 
                    format('%s tasks still active for COMPLETED order', v_active_count);
            END IF;
        ELSE
            RETURN QUERY SELECT 'INV-3'::VARCHAR, TRUE, 'Order not COMPLETED yet, skipping terminal check';
        END IF;
    ELSE
        -- INV-5: No tasks for instant order
        SELECT COUNT(*) INTO v_active_count
        FROM order_tasks WHERE order_id = p_order_id;
        
        IF v_active_count = 0 THEN
            RETURN QUERY SELECT 'INV-5'::VARCHAR, TRUE, 'No tasks for instant order';
        ELSE
            RETURN QUERY SELECT 'INV-5'::VARCHAR, FALSE, 
                format('Instant order has %s tasks (should be 0)', v_active_count);
        END IF;
        
        -- INV-6: Delivered matches quantity for instant
        IF v_order.status = 'COMPLETED' THEN
            IF v_order.delivered = v_order.quantity THEN
                RETURN QUERY SELECT 'INV-6'::VARCHAR, TRUE, 
                    format('Delivered %s matches quantity', v_order.delivered);
            ELSE
                RETURN QUERY SELECT 'INV-6'::VARCHAR, FALSE, 
                    format('Delivered %s != quantity %s', v_order.delivered, v_order.quantity);
            END IF;
        ELSE
            RETURN QUERY SELECT 'INV-6'::VARCHAR, TRUE, 'Order not COMPLETED yet';
        END IF;
    END IF;
END;
$$;


--
-- Name: FUNCTION check_order_invariants(p_order_id uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.check_order_invariants(p_order_id uuid) IS 'Manual invariant verification for debugging';


--
-- Name: prevent_price_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.prevent_price_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Block changes to price_per_unit once set
    IF OLD.price_per_unit IS NOT NULL 
       AND NEW.price_per_unit IS DISTINCT FROM OLD.price_per_unit THEN
        RAISE EXCEPTION 'price_per_unit is immutable after order creation';
    END IF;
    
    -- Block changes to cost once charged (> 0)
    IF OLD.cost IS NOT NULL 
       AND OLD.cost > 0 
       AND NEW.cost IS DISTINCT FROM OLD.cost THEN
        RAISE EXCEPTION 'cost is immutable after order creation';
    END IF;
    
    -- Block changes to total_cost once charged (> 0)
    IF OLD.total_cost IS NOT NULL 
       AND OLD.total_cost > 0 
       AND NEW.total_cost IS DISTINCT FROM OLD.total_cost THEN
        RAISE EXCEPTION 'total_cost is immutable after order creation';
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- Name: FUNCTION prevent_price_change(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.prevent_price_change() IS 'Prevents modification of pricing fields after order creation to ensure refund integrity';


--
-- Name: select_best_proxy(character varying, double precision); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.select_best_proxy(p_target_country character varying DEFAULT NULL::character varying, p_min_success_rate double precision DEFAULT 0.70) RETURNS TABLE(proxy_id uuid, proxy_ip character varying, proxy_port integer, tier character varying, health_state character varying, success_rate double precision, load_percent double precision, is_degraded boolean)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    WITH ranked_proxies AS (
        SELECT 
            v.id,
            v.public_ip,
            v.port,
            v.tier,
            v.health_state,
            v.success_rate,
            v.load_percent,
            v.health_state = 'DEGRADED' AS is_degraded_flag,
            -- Tier rank: MOBILE=1, RESIDENTIAL=2, ISP=3, DATACENTER=4
            CASE v.tier
                WHEN 'MOBILE' THEN 1
                WHEN 'RESIDENTIAL' THEN 2
                WHEN 'ISP' THEN 3
                WHEN 'DATACENTER' THEN 4
                ELSE 5
            END AS tier_rank,
            -- Health rank: HEALTHY=1, DEGRADED=2
            CASE v.health_state
                WHEN 'HEALTHY' THEN 1
                WHEN 'DEGRADED' THEN 2
                ELSE 3
            END AS health_rank
        FROM v_proxy_selection v
        WHERE v.status = 'ONLINE'
          AND v.health_state IN ('HEALTHY', 'DEGRADED')
          AND v.success_rate >= p_min_success_rate
          AND (p_target_country IS NULL OR v.country = p_target_country)
    )
    SELECT 
        r.id,
        r.public_ip,
        r.port,
        r.tier,
        r.health_state,
        r.success_rate,
        r.load_percent,
        r.is_degraded_flag
    FROM ranked_proxies r
    ORDER BY 
        r.health_rank ASC,     -- Prefer HEALTHY over DEGRADED
        r.tier_rank ASC,       -- Prefer MOBILE > RESIDENTIAL > ISP > DATACENTER
        r.load_percent ASC     -- Prefer lowest load
    LIMIT 1;
END;
$$;


--
-- Name: FUNCTION select_best_proxy(p_target_country character varying, p_min_success_rate double precision); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.select_best_proxy(p_target_country character varying, p_min_success_rate double precision) IS 'Select best available proxy per architecture spec';


--
-- Name: update_proxy_health_state(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_proxy_health_state() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_success_rate DOUBLE PRECISION;
    v_new_state VARCHAR(20);
BEGIN
    v_success_rate := NEW.success_rate;
    
    -- Determine health state based on success rate thresholds
    IF v_success_rate >= 0.85 THEN
        v_new_state := 'HEALTHY';
    ELSIF v_success_rate >= 0.70 THEN
        v_new_state := 'DEGRADED';
    ELSE
        v_new_state := 'OFFLINE';
    END IF;
    
    -- Update the proxy node's health state
    UPDATE proxy_nodes 
    SET health_state = v_new_state
    WHERE id = NEW.proxy_node_id;
    
    -- Log state transitions for monitoring
    IF TG_OP = 'UPDATE' AND OLD.success_rate IS DISTINCT FROM NEW.success_rate THEN
        RAISE NOTICE 'PROXY_HEALTH_CHANGE | nodeId=% | oldRate=% | newRate=% | newState=%',
            NEW.proxy_node_id, OLD.success_rate, NEW.success_rate, v_new_state;
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- Name: verify_order_completion_invariants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.verify_order_completion_invariants() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    task_delivered INTEGER;
    task_failed INTEGER;
    uses_tasks BOOLEAN;
BEGIN
    -- Only check when transitioning to COMPLETED
    IF NEW.status = 'COMPLETED' AND (OLD.status IS NULL OR OLD.status != 'COMPLETED') THEN
        uses_tasks := COALESCE(NEW.uses_task_delivery, FALSE);
        
        IF uses_tasks THEN
            -- Count delivered from COMPLETED tasks
            SELECT COALESCE(SUM(quantity), 0) INTO task_delivered
            FROM order_tasks 
            WHERE order_id = NEW.id AND status = 'COMPLETED';
            
            -- Count failed from FAILED_PERMANENT tasks
            SELECT COALESCE(SUM(quantity), 0) INTO task_failed
            FROM order_tasks 
            WHERE order_id = NEW.id AND status = 'FAILED_PERMANENT';
            
            -- Verify INV-1: quantity accounting
            IF (task_delivered + task_failed) != NEW.quantity THEN
                INSERT INTO invariant_check_log(check_type, order_id, passed, violations_count, violation_details)
                VALUES ('ORDER_COMPLETION', NEW.id, FALSE, 1, jsonb_build_object(
                    'invariant', 'INV-1',
                    'expected', NEW.quantity,
                    'task_delivered', task_delivered,
                    'task_failed', task_failed,
                    'actual_sum', task_delivered + task_failed
                ));
                
                -- Raise warning but don't block - let application handle
                RAISE WARNING 'INV-1 violation for order %: expected %, got %', 
                    NEW.id, NEW.quantity, task_delivered + task_failed;
            ELSE
                -- Log successful check
                INSERT INTO invariant_check_log(check_type, order_id, passed, violations_count)
                VALUES ('ORDER_COMPLETION', NEW.id, TRUE, 0);
            END IF;
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: balance_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.balance_transactions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    order_id uuid,
    amount numeric(10,2) NOT NULL,
    balance_before numeric(12,2) NOT NULL,
    balance_after numeric(12,2) NOT NULL,
    type character varying(50) NOT NULL,
    reason character varying(500) NOT NULL,
    payment_provider character varying(50),
    external_tx_id character varying(128),
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT balance_tx_balance_consistent CHECK (((((type)::text = 'DEBIT'::text) AND (amount < (0)::numeric)) OR (((type)::text = ANY ((ARRAY['CREDIT'::character varying, 'REFUND'::character varying, 'BONUS'::character varying])::text[])) AND (amount > (0)::numeric)) OR ((type)::text = 'ADJUSTMENT'::text))),
    CONSTRAINT balance_tx_type_check CHECK (((type)::text = ANY ((ARRAY['DEBIT'::character varying, 'CREDIT'::character varying, 'REFUND'::character varying, 'BONUS'::character varying, 'ADJUSTMENT'::character varying])::text[])))
);


--
-- Name: TABLE balance_transactions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.balance_transactions IS 'Financial ledger for user balance changes';


--
-- Name: COLUMN balance_transactions.amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.balance_transactions.amount IS 'Positive for credits, negative for debits';


--
-- Name: device_nodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_nodes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    device_type character varying(50) NOT NULL,
    os_version character varying(50) NOT NULL,
    device_model character varying(100),
    app_version character varying(20),
    location character varying(100) NOT NULL,
    country character varying(2) NOT NULL,
    timezone character varying(50) NOT NULL,
    capacity integer DEFAULT 10 NOT NULL,
    active_sessions integer DEFAULT 0 NOT NULL,
    last_heartbeat timestamp with time zone,
    status character varying(50) DEFAULT 'ACTIVE'::character varying NOT NULL,
    fingerprint character varying(500),
    registered_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    retired_at timestamp with time zone,
    CONSTRAINT device_nodes_capacity_positive CHECK ((capacity > 0)),
    CONSTRAINT device_nodes_sessions_valid CHECK ((active_sessions >= 0)),
    CONSTRAINT device_nodes_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'IDLE'::character varying, 'MAINTENANCE'::character varying, 'RETIRED'::character varying])::text[]))),
    CONSTRAINT device_nodes_type_check CHECK (((device_type)::text = ANY ((ARRAY['PHONE_ANDROID'::character varying, 'PHONE_IOS'::character varying, 'EMULATOR_ANDROID'::character varying, 'EMULATOR_IOS'::character varying, 'DESKTOP_WEB'::character varying, 'MOBILE_WEB'::character varying])::text[])))
);


--
-- Name: TABLE device_nodes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.device_nodes IS 'Emulator/device farm for Spotify client simulation';


--
-- Name: COLUMN device_nodes.fingerprint; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.device_nodes.fingerprint IS 'Device fingerprint data for anti-detection';


--
-- Name: invariant_check_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invariant_check_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    check_timestamp timestamp with time zone DEFAULT now(),
    check_type character varying(50) NOT NULL,
    order_id uuid,
    passed boolean NOT NULL,
    violations_count integer DEFAULT 0,
    violation_details jsonb,
    execution_time_ms integer
);


--
-- Name: order_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_tasks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    order_id uuid NOT NULL,
    sequence_number integer NOT NULL,
    quantity integer NOT NULL,
    status character varying(30) DEFAULT 'PENDING'::character varying NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    max_attempts integer DEFAULT 3 NOT NULL,
    last_error character varying(1000),
    proxy_node_id uuid,
    execution_started_at timestamp with time zone,
    executed_at timestamp with time zone,
    scheduled_at timestamp with time zone NOT NULL,
    retry_after timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    idempotency_token character varying(128) NOT NULL,
    worker_id character varying(64),
    refunded boolean DEFAULT false NOT NULL,
    CONSTRAINT chk_attempts_not_exceed_max CHECK (((attempts >= 0) AND (attempts <= max_attempts))),
    CONSTRAINT chk_no_completed_refund CHECK ((NOT (((status)::text = 'COMPLETED'::text) AND (refunded = true)))),
    CONSTRAINT chk_sequence_non_negative CHECK ((sequence_number >= 0)),
    CONSTRAINT chk_task_quantity_positive CHECK (((quantity > 0) AND (quantity <= 1000))),
    CONSTRAINT chk_valid_task_status CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'EXECUTING'::character varying, 'COMPLETED'::character varying, 'FAILED_RETRYING'::character varying, 'FAILED_PERMANENT'::character varying])::text[]))),
    CONSTRAINT order_tasks_quantity_check CHECK (((quantity > 0) AND (quantity <= 1000)))
);


--
-- Name: TABLE order_tasks; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.order_tasks IS 'Granular execution units for 15k order delivery. Each task delivers 200-500 plays atomically.';


--
-- Name: COLUMN order_tasks.sequence_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.order_tasks.sequence_number IS 'Task sequence within order (1, 2, 3...) for ordering and idempotency';


--
-- Name: COLUMN order_tasks.status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.order_tasks.status IS 'PENDING|EXECUTING|COMPLETED|FAILED_RETRYING|FAILED_PERMANENT';


--
-- Name: COLUMN order_tasks.attempts; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.order_tasks.attempts IS 'Number of execution attempts (incremented each try)';


--
-- Name: COLUMN order_tasks.max_attempts; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.order_tasks.max_attempts IS 'Maximum attempts before FAILED_PERMANENT (default 3)';


--
-- Name: COLUMN order_tasks.scheduled_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.order_tasks.scheduled_at IS 'When task should execute (spread across 48-72h window)';


--
-- Name: COLUMN order_tasks.retry_after; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.order_tasks.retry_after IS 'Earliest time to retry after transient failure (exponential backoff)';


--
-- Name: COLUMN order_tasks.idempotency_token; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.order_tasks.idempotency_token IS 'Format: {orderId}:{sequenceNumber}:{attempt} - prevents double delivery';


--
-- Name: COLUMN order_tasks.worker_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.order_tasks.worker_id IS 'ID of worker processing this task (for orphan detection)';


--
-- Name: COLUMN order_tasks.refunded; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.order_tasks.refunded IS 'TRUE if balance was credited back for this failed task. Prevents double-refunds.';


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    service_id uuid NOT NULL,
    quantity integer NOT NULL,
    delivered integer DEFAULT 0 NOT NULL,
    target_url character varying(512) NOT NULL,
    geo_profile character varying(50) DEFAULT 'WORLDWIDE'::character varying NOT NULL,
    speed_multiplier double precision DEFAULT 1.0 NOT NULL,
    status character varying(50) DEFAULT 'PENDING'::character varying NOT NULL,
    total_cost numeric(10,2) NOT NULL,
    refund_amount numeric(10,2) DEFAULT 0.00 NOT NULL,
    start_count integer,
    current_count integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    failure_reason character varying(500),
    internal_notes character varying(1000),
    external_order_id character varying(64),
    webhook_delivered boolean DEFAULT false NOT NULL,
    service_name character varying(255),
    price_per_unit numeric(10,4),
    remains integer DEFAULT 0 NOT NULL,
    estimated_completion_at timestamp without time zone,
    failed_permanent_plays integer DEFAULT 0 NOT NULL,
    uses_task_delivery boolean DEFAULT false NOT NULL,
    CONSTRAINT chk_delivered_not_exceed_quantity CHECK (((delivered >= 0) AND (delivered <= quantity))),
    CONSTRAINT chk_failed_permanent_not_exceed_quantity CHECK (((failed_permanent_plays IS NULL) OR ((failed_permanent_plays >= 0) AND (failed_permanent_plays <= quantity)))),
    CONSTRAINT chk_order_quantity_positive CHECK ((quantity > 0)),
    CONSTRAINT chk_quantity_cap CHECK (((delivered + COALESCE(failed_permanent_plays, 0)) <= quantity)),
    CONSTRAINT orders_cost_positive CHECK ((total_cost >= (0)::numeric)),
    CONSTRAINT orders_delivered_valid CHECK (((delivered >= 0) AND (delivered <= quantity))),
    CONSTRAINT orders_geo_profile_check CHECK (((geo_profile)::text = ANY ((ARRAY['WORLDWIDE'::character varying, 'USA'::character varying, 'UK'::character varying, 'DE'::character varying, 'FR'::character varying, 'BR'::character varying, 'MX'::character varying, 'LATAM'::character varying, 'EUROPE'::character varying, 'ASIA'::character varying, 'PREMIUM_MIX'::character varying])::text[]))),
    CONSTRAINT orders_quantity_positive CHECK ((quantity > 0)),
    CONSTRAINT orders_speed_valid CHECK (((speed_multiplier >= (0.1)::double precision) AND (speed_multiplier <= (5.0)::double precision))),
    CONSTRAINT orders_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'VALIDATING'::character varying, 'RUNNING'::character varying, 'COMPLETED'::character varying, 'PARTIAL'::character varying, 'FAILED'::character varying, 'REFUNDED'::character varying, 'CANCELLED'::character varying])::text[]))),
    CONSTRAINT orders_target_url_valid CHECK (((target_url)::text ~ '^https://(open\.)?spotify\.com/.*$'::text))
);


--
-- Name: TABLE orders; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.orders IS 'Spotify engagement delivery orders (aggregate root)';


--
-- Name: COLUMN orders.total_cost; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.orders.total_cost IS 'Total order cost (quantity * price_per_unit)';


--
-- Name: COLUMN orders.start_count; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.orders.start_count IS 'Initial metric count when order started';


--
-- Name: COLUMN orders.current_count; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.orders.current_count IS 'Latest scraped metric count';


--
-- Name: COLUMN orders.external_order_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.orders.external_order_id IS 'ID from external API integrations';


--
-- Name: COLUMN orders.service_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.orders.service_name IS 'Denormalized service name for display (avoid JOIN)';


--
-- Name: COLUMN orders.price_per_unit; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.orders.price_per_unit IS 'Price per unit at time of order (for historical accuracy)';


--
-- Name: COLUMN orders.remains; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.orders.remains IS 'Remaining quantity to deliver (quantity - delivered)';


--
-- Name: COLUMN orders.estimated_completion_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.orders.estimated_completion_at IS 'ETA calculated by CapacityService at order creation';


--
-- Name: COLUMN orders.failed_permanent_plays; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.orders.failed_permanent_plays IS 'Count of plays that permanently failed (dead-letter queue)';


--
-- Name: COLUMN orders.uses_task_delivery; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.orders.uses_task_delivery IS 'True if order uses task-based delivery (15k+ orders)';


--
-- Name: premium_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.premium_accounts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(100) NOT NULL,
    password character varying(100),
    cookies text,
    spotify_refresh_token text,
    spotify_access_token text,
    region character varying(20) DEFAULT 'WORLDWIDE'::character varying,
    premium_expiry date NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE premium_accounts; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.premium_accounts IS 'Spotify premium accounts for bot farm operations';


--
-- Name: COLUMN premium_accounts.cookies; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.premium_accounts.cookies IS 'JSON browser cookies for session persistence';


--
-- Name: COLUMN premium_accounts.premium_expiry; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.premium_accounts.premium_expiry IS 'Date when premium subscription expires';


--
-- Name: proxy_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.proxy_metrics (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    proxy_node_id uuid NOT NULL,
    total_requests bigint DEFAULT 0 NOT NULL,
    successful_requests bigint DEFAULT 0 NOT NULL,
    failed_requests bigint DEFAULT 0 NOT NULL,
    success_rate double precision DEFAULT 1.0 NOT NULL,
    ban_rate double precision DEFAULT 0.0 NOT NULL,
    latency_p50 integer DEFAULT 0 NOT NULL,
    latency_p95 integer DEFAULT 0 NOT NULL,
    latency_p99 integer DEFAULT 0 NOT NULL,
    active_connections integer DEFAULT 0 NOT NULL,
    peak_connections integer DEFAULT 0 NOT NULL,
    error_codes text,
    bytes_transferred bigint DEFAULT 0 NOT NULL,
    estimated_cost numeric(10,4) DEFAULT 0.0000 NOT NULL,
    last_updated timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    window_start timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT proxy_metrics_latency_positive CHECK (((latency_p50 >= 0) AND (latency_p95 >= 0) AND (latency_p99 >= 0))),
    CONSTRAINT proxy_metrics_rates_valid CHECK (((success_rate >= (0.0)::double precision) AND (success_rate <= (1.0)::double precision) AND (ban_rate >= (0.0)::double precision) AND (ban_rate <= (1.0)::double precision)))
);


--
-- Name: TABLE proxy_metrics; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.proxy_metrics IS 'Real-time rolling metrics for proxy health monitoring';


--
-- Name: COLUMN proxy_metrics.error_codes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.proxy_metrics.error_codes IS 'JSON object: {"401": count, "403": count, "429": count}';


--
-- Name: COLUMN proxy_metrics.window_start; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.proxy_metrics.window_start IS 'Start of current rolling metrics window';


--
-- Name: proxy_nodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.proxy_nodes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    provider character varying(50) NOT NULL,
    provider_instance_id character varying(64),
    public_ip character varying(45) NOT NULL,
    port integer NOT NULL,
    region character varying(50) NOT NULL,
    country character varying(2) NOT NULL,
    city character varying(100),
    tier character varying(50) NOT NULL,
    capacity integer DEFAULT 100 NOT NULL,
    current_load integer DEFAULT 0 NOT NULL,
    cost_per_hour numeric(8,4) DEFAULT 0.0000 NOT NULL,
    auth_username character varying(64),
    auth_password character varying(128),
    registered_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_healthcheck timestamp with time zone,
    status character varying(50) DEFAULT 'ONLINE'::character varying NOT NULL,
    tags text,
    health_state character varying(20) DEFAULT 'HEALTHY'::character varying NOT NULL,
    CONSTRAINT proxy_nodes_capacity_positive CHECK ((capacity > 0)),
    CONSTRAINT proxy_nodes_health_state_check CHECK (((health_state)::text = ANY ((ARRAY['HEALTHY'::character varying, 'DEGRADED'::character varying, 'OFFLINE'::character varying])::text[]))),
    CONSTRAINT proxy_nodes_load_valid CHECK ((current_load >= 0)),
    CONSTRAINT proxy_nodes_port_valid CHECK (((port >= 1) AND (port <= 65535))),
    CONSTRAINT proxy_nodes_provider_check CHECK (((provider)::text = ANY ((ARRAY['VULTR'::character varying, 'HETZNER'::character varying, 'NETCUP'::character varying, 'CONTABO'::character varying, 'OVH'::character varying, 'AWS'::character varying, 'DIGITALOCEAN'::character varying, 'LINODE'::character varying])::text[]))),
    CONSTRAINT proxy_nodes_status_check CHECK (((status)::text = ANY ((ARRAY['ONLINE'::character varying, 'OFFLINE'::character varying, 'MAINTENANCE'::character varying, 'BANNED'::character varying, 'RATE_LIMITED'::character varying])::text[]))),
    CONSTRAINT proxy_nodes_tier_check CHECK (((tier)::text = ANY ((ARRAY['DATACENTER'::character varying, 'ISP'::character varying, 'TOR'::character varying, 'RESIDENTIAL'::character varying, 'MOBILE'::character varying])::text[])))
);


--
-- Name: TABLE proxy_nodes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.proxy_nodes IS 'Distributed proxy pool across multiple providers';


--
-- Name: COLUMN proxy_nodes.tier; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.proxy_nodes.tier IS 'Quality tier: DATACENTER < ISP < TOR < RESIDENTIAL < MOBILE';


--
-- Name: COLUMN proxy_nodes.tags; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.proxy_nodes.tags IS 'JSON array for flexible categorization';


--
-- Name: refund_anomalies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refund_anomalies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_id uuid NOT NULL,
    detected_at timestamp with time zone DEFAULT now() NOT NULL,
    anomaly_type character varying(50) NOT NULL,
    expected_refund_amount numeric(12,4),
    actual_refund_amount numeric(12,4),
    expected_failed_plays integer,
    actual_failed_plays integer,
    refunded_task_count integer,
    severity character varying(20) DEFAULT 'WARNING'::character varying NOT NULL,
    resolved_at timestamp with time zone,
    resolution_notes text,
    CONSTRAINT chk_anomaly_severity CHECK (((severity)::text = ANY ((ARRAY['INFO'::character varying, 'WARNING'::character varying, 'CRITICAL'::character varying])::text[]))),
    CONSTRAINT chk_anomaly_type CHECK (((anomaly_type)::text = ANY ((ARRAY['REFUND_AMOUNT_MISMATCH'::character varying, 'FAILED_PLAYS_MISMATCH'::character varying, 'ORPHAN_REFUND_EVENT'::character varying, 'DOUBLE_REFUND_DETECTED'::character varying, 'BALANCE_DRIFT'::character varying])::text[])))
);


--
-- Name: TABLE refund_anomalies; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.refund_anomalies IS 'Records detected discrepancies between order aggregates and task-level refund data.';


--
-- Name: refund_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refund_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_id uuid NOT NULL,
    task_id uuid NOT NULL,
    user_id uuid NOT NULL,
    quantity integer NOT NULL,
    amount numeric(12,4) NOT NULL,
    price_per_unit numeric(12,8) NOT NULL,
    worker_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE refund_events; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.refund_events IS 'Append-only audit log of all refund credits. One row per refunded task.';


--
-- Name: services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.services (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(100) NOT NULL,
    display_name character varying(255) NOT NULL,
    service_type character varying(50) NOT NULL,
    description character varying(1000),
    cost_per_1k numeric(8,2) NOT NULL,
    reseller_cost_per_1k numeric(8,2) NOT NULL,
    agency_cost_per_1k numeric(8,2) NOT NULL,
    min_quantity integer DEFAULT 100 NOT NULL,
    max_quantity integer DEFAULT 1000000 NOT NULL,
    estimated_days_min integer DEFAULT 1 NOT NULL,
    estimated_days_max integer DEFAULT 7 NOT NULL,
    geo_profiles jsonb DEFAULT '["WORLDWIDE"]'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT services_cost_positive CHECK ((cost_per_1k > (0)::numeric)),
    CONSTRAINT services_quantity_valid CHECK (((min_quantity > 0) AND (max_quantity >= min_quantity))),
    CONSTRAINT services_type_check CHECK (((service_type)::text = ANY ((ARRAY['PLAYS'::character varying, 'MONTHLY_LISTENERS'::character varying, 'SAVES'::character varying, 'FOLLOWS'::character varying, 'PLAYLIST_FOLLOWERS'::character varying, 'PLAYLIST_PLAYS'::character varying])::text[])))
);


--
-- Name: TABLE services; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.services IS 'Catalog of Spotify engagement services';


--
-- Name: COLUMN services.geo_profiles; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.services.geo_profiles IS 'JSON array of supported GeoProfile values';


--
-- Name: tor_circuits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tor_circuits (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    circuit_id character varying(64) NOT NULL,
    entry_node character varying(100) NOT NULL,
    middle_node character varying(100),
    exit_node character varying(100) NOT NULL,
    exit_geo character varying(2) NOT NULL,
    success_rate double precision DEFAULT 1.0 NOT NULL,
    latency_p95 integer DEFAULT 0 NOT NULL,
    request_count bigint DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    retired_at timestamp with time zone,
    status character varying(50) DEFAULT 'ACTIVE'::character varying NOT NULL,
    CONSTRAINT tor_circuits_expires_future CHECK ((expires_at > created_at)),
    CONSTRAINT tor_circuits_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'RETIRED'::character varying, 'EXPIRED'::character varying, 'BLOCKED'::character varying])::text[]))),
    CONSTRAINT tor_circuits_success_rate_valid CHECK (((success_rate >= (0.0)::double precision) AND (success_rate <= (1.0)::double precision)))
);


--
-- Name: TABLE tor_circuits; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tor_circuits IS 'Tor exit node circuits for anonymized traffic';


--
-- Name: COLUMN tor_circuits.exit_geo; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tor_circuits.exit_geo IS 'ISO 3166-1 alpha-2 country code of exit node';


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    tier character varying(50) DEFAULT 'CONSUMER'::character varying NOT NULL,
    balance numeric(12,2) DEFAULT 0.00 NOT NULL,
    api_key character varying(64),
    webhook_url character varying(512),
    discord_webhook character varying(512),
    company_name character varying(255),
    referral_code character varying(32),
    referred_by uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_login timestamp with time zone,
    status character varying(50) DEFAULT 'ACTIVE'::character varying NOT NULL,
    email_verified boolean DEFAULT false NOT NULL,
    two_factor_enabled boolean DEFAULT false NOT NULL,
    CONSTRAINT users_balance_positive CHECK ((balance >= (0)::numeric)),
    CONSTRAINT users_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'ACTIVE'::character varying, 'SUSPENDED'::character varying, 'BANNED'::character varying, 'PENDING_VERIFICATION'::character varying])::text[]))),
    CONSTRAINT users_tier_check CHECK (((tier)::text = ANY ((ARRAY['CONSUMER'::character varying, 'RESELLER'::character varying, 'AGENCY'::character varying])::text[])))
);


--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.users IS 'Platform users with tiered pricing (CONSUMER/RESELLER/AGENCY)';


--
-- Name: COLUMN users.tier; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.users.tier IS 'Pricing tier: CONSUMER (base), RESELLER (20-30% off), AGENCY (40-50% off)';


--
-- Name: COLUMN users.api_key; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.users.api_key IS '64-char key for programmatic API access';


--
-- Name: v_invariant_health; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_invariant_health AS
 SELECT ( SELECT count(*) AS count
           FROM public.invariant_check_log
          WHERE ((invariant_check_log.passed = false) AND (invariant_check_log.check_timestamp > (now() - '24:00:00'::interval)))) AS violations_24h,
    ( SELECT count(*) AS count
           FROM public.order_tasks
          WHERE (((order_tasks.status)::text = 'EXECUTING'::text) AND (order_tasks.execution_started_at < (now() - '00:02:00'::interval)))) AS orphaned_tasks,
    ( SELECT count(*) AS count
           FROM public.orders o
          WHERE (((o.status)::text = 'COMPLETED'::text) AND (o.uses_task_delivery = true) AND (o.delivered <> ( SELECT COALESCE(sum(t.quantity), (0)::bigint) AS "coalesce"
                   FROM public.order_tasks t
                  WHERE ((t.order_id = o.id) AND ((t.status)::text = 'COMPLETED'::text)))))) AS mismatched_delivered,
    ( SELECT count(*) AS count
           FROM public.orders o
          WHERE (((o.status)::text = 'COMPLETED'::text) AND (o.uses_task_delivery = true) AND (EXISTS ( SELECT 1
                   FROM public.order_tasks t
                  WHERE ((t.order_id = o.id) AND ((t.status)::text <> ALL ((ARRAY['COMPLETED'::character varying, 'FAILED_PERMANENT'::character varying])::text[]))))))) AS completed_with_active_tasks,
    ( SELECT count(*) AS count
           FROM public.invariant_check_log
          WHERE (invariant_check_log.check_timestamp > (now() - '24:00:00'::interval))) AS total_checks_24h;


--
-- Name: VIEW v_invariant_health; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.v_invariant_health IS 'Real-time invariant health metrics - all values should be 0';


--
-- Name: v_proxy_selection; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_proxy_selection AS
 SELECT pn.id,
    pn.provider,
    pn.public_ip,
    pn.port,
    pn.region,
    pn.country,
    pn.city,
    pn.tier,
    pn.capacity,
    pn.current_load,
    pn.cost_per_hour,
    pn.auth_username,
    pn.auth_password,
    pn.status,
    pn.health_state,
    COALESCE(pm.success_rate, (1.0)::double precision) AS success_rate,
    COALESCE(pm.ban_rate, (0.0)::double precision) AS ban_rate,
    COALESCE(pm.latency_p50, 0) AS latency_p50,
    COALESCE(pm.latency_p95, 0) AS latency_p95,
    COALESCE(pm.total_requests, (0)::bigint) AS total_requests,
    COALESCE(pm.active_connections, 0) AS active_connections,
        CASE
            WHEN (pn.capacity > 0) THEN (((pn.current_load)::double precision / (pn.capacity)::double precision) * (100)::double precision)
            ELSE (100)::double precision
        END AS load_percent,
    ((COALESCE(pm.success_rate, (1.0)::double precision) * ((1)::double precision - (((pn.current_load)::double precision / (GREATEST(pn.capacity, 1))::double precision) * (0.3)::double precision))) * (
        CASE pn.tier
            WHEN 'MOBILE'::text THEN 1.3
            WHEN 'RESIDENTIAL'::text THEN 1.2
            WHEN 'ISP'::text THEN 1.1
            WHEN 'DATACENTER'::text THEN 1.0
            ELSE 0.9
        END)::double precision) AS selection_score
   FROM (public.proxy_nodes pn
     LEFT JOIN public.proxy_metrics pm ON ((pn.id = pm.proxy_node_id)));


--
-- Name: VIEW v_proxy_selection; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.v_proxy_selection IS 'Unified view for proxy selection with computed scores';


--
-- Data for Name: balance_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.balance_transactions (id, user_id, order_id, amount, balance_before, balance_after, type, reason, payment_provider, external_tx_id, "timestamp") FROM stdin;
\.


--
-- Data for Name: device_nodes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.device_nodes (id, device_type, os_version, device_model, app_version, location, country, timezone, capacity, active_sessions, last_heartbeat, status, fingerprint, registered_at, retired_at) FROM stdin;
\.


--
-- Data for Name: invariant_check_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invariant_check_log (id, check_timestamp, check_type, order_id, passed, violations_count, violation_details, execution_time_ms) FROM stdin;
\.


--
-- Data for Name: order_tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_tasks (id, order_id, sequence_number, quantity, status, attempts, max_attempts, last_error, proxy_node_id, execution_started_at, executed_at, scheduled_at, retry_after, created_at, idempotency_token, worker_id, refunded) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orders (id, user_id, service_id, quantity, delivered, target_url, geo_profile, speed_multiplier, status, total_cost, refund_amount, start_count, current_count, created_at, started_at, completed_at, failure_reason, internal_notes, external_order_id, webhook_delivered, service_name, price_per_unit, remains, estimated_completion_at, failed_permanent_plays, uses_task_delivery) FROM stdin;
\.


--
-- Data for Name: premium_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.premium_accounts (id, email, password, cookies, spotify_refresh_token, spotify_access_token, region, premium_expiry, created_at) FROM stdin;
\.


--
-- Data for Name: proxy_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.proxy_metrics (id, proxy_node_id, total_requests, successful_requests, failed_requests, success_rate, ban_rate, latency_p50, latency_p95, latency_p99, active_connections, peak_connections, error_codes, bytes_transferred, estimated_cost, last_updated, window_start) FROM stdin;
\.


--
-- Data for Name: proxy_nodes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.proxy_nodes (id, provider, provider_instance_id, public_ip, port, region, country, city, tier, capacity, current_load, cost_per_hour, auth_username, auth_password, registered_at, last_healthcheck, status, tags, health_state) FROM stdin;
\.


--
-- Data for Name: refund_anomalies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refund_anomalies (id, order_id, detected_at, anomaly_type, expected_refund_amount, actual_refund_amount, expected_failed_plays, actual_failed_plays, refunded_task_count, severity, resolved_at, resolution_notes) FROM stdin;
\.


--
-- Data for Name: refund_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refund_events (id, order_id, task_id, user_id, quantity, amount, price_per_unit, worker_id, created_at) FROM stdin;
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.services (id, name, display_name, service_type, description, cost_per_1k, reseller_cost_per_1k, agency_cost_per_1k, min_quantity, max_quantity, estimated_days_min, estimated_days_max, geo_profiles, is_active, sort_order, created_at, updated_at) FROM stdin;
914058b2-50eb-4b45-9d2b-983261d9ce18	plays_ww	Worldwide Plays	PLAYS	Global stream distribution from mixed geo sources	2.50	2.00	1.50	1000	10000000	1	7	["WORLDWIDE"]	t	1	2026-01-19 15:47:52.749535+00	2026-01-19 15:47:52.749535+00
0d550af3-2994-4f6b-bdab-d4144a9fc466	plays_usa	USA Premium Plays	PLAYS	High-quality streams from verified US accounts	4.50	3.60	2.70	1000	5000000	2	10	["USA"]	t	2	2026-01-19 15:47:52.749535+00	2026-01-19 15:47:52.749535+00
314e178e-f93d-40cd-be08-bef7916a51c9	plays_eu	European Plays	PLAYS	Streams from EU region (UK, DE, FR, etc.)	3.50	2.80	2.10	1000	5000000	2	10	["EUROPE", "UK", "DE", "FR"]	t	3	2026-01-19 15:47:52.749535+00	2026-01-19 15:47:52.749535+00
ffb6adc2-1fda-4e09-8997-a719fba8e6bd	monthly_listeners	Monthly Listeners	MONTHLY_LISTENERS	Unique monthly listeners (28-day retention)	8.00	6.40	4.80	100	100000	7	30	["WORLDWIDE", "USA", "EUROPE"]	t	4	2026-01-19 15:47:52.749535+00	2026-01-19 15:47:52.749535+00
dfca4e04-56f8-48c0-bd62-4bfe6b74a843	saves	Track Saves	SAVES	Save tracks to user libraries	5.00	4.00	3.00	100	500000	1	7	["WORLDWIDE"]	t	5	2026-01-19 15:47:52.749535+00	2026-01-19 15:47:52.749535+00
2207a7b6-a59c-40cc-b202-eab9824b1efb	follows	Artist Follows	FOLLOWS	Followers for artist profiles	6.00	4.80	3.60	100	500000	1	7	["WORLDWIDE"]	t	6	2026-01-19 15:47:52.749535+00	2026-01-19 15:47:52.749535+00
f62d3a66-c0d0-40c1-86c0-ece45709da18	playlist_follows	Playlist Followers	PLAYLIST_FOLLOWERS	Followers for public playlists	4.00	3.20	2.40	100	100000	1	5	["WORLDWIDE"]	t	7	2026-01-19 15:47:52.749535+00	2026-01-19 15:47:52.749535+00
\.


--
-- Data for Name: tor_circuits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tor_circuits (id, circuit_id, entry_node, middle_node, exit_node, exit_geo, success_rate, latency_p95, request_count, created_at, expires_at, retired_at, status) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, tier, balance, api_key, webhook_url, discord_webhook, company_name, referral_code, referred_by, created_at, last_login, status, email_verified, two_factor_enabled) FROM stdin;
\.


--
-- Name: balance_transactions balance_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balance_transactions
    ADD CONSTRAINT balance_transactions_pkey PRIMARY KEY (id);


--
-- Name: device_nodes device_nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_nodes
    ADD CONSTRAINT device_nodes_pkey PRIMARY KEY (id);


--
-- Name: invariant_check_log invariant_check_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invariant_check_log
    ADD CONSTRAINT invariant_check_log_pkey PRIMARY KEY (id);


--
-- Name: order_tasks order_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_tasks
    ADD CONSTRAINT order_tasks_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: premium_accounts premium_accounts_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.premium_accounts
    ADD CONSTRAINT premium_accounts_email_unique UNIQUE (email);


--
-- Name: premium_accounts premium_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.premium_accounts
    ADD CONSTRAINT premium_accounts_pkey PRIMARY KEY (id);


--
-- Name: proxy_metrics proxy_metrics_node_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proxy_metrics
    ADD CONSTRAINT proxy_metrics_node_unique UNIQUE (proxy_node_id);


--
-- Name: proxy_metrics proxy_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proxy_metrics
    ADD CONSTRAINT proxy_metrics_pkey PRIMARY KEY (id);


--
-- Name: proxy_nodes proxy_nodes_ip_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proxy_nodes
    ADD CONSTRAINT proxy_nodes_ip_unique UNIQUE (public_ip);


--
-- Name: proxy_nodes proxy_nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proxy_nodes
    ADD CONSTRAINT proxy_nodes_pkey PRIMARY KEY (id);


--
-- Name: refund_anomalies refund_anomalies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refund_anomalies
    ADD CONSTRAINT refund_anomalies_pkey PRIMARY KEY (id);


--
-- Name: refund_events refund_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refund_events
    ADD CONSTRAINT refund_events_pkey PRIMARY KEY (id);


--
-- Name: services services_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_name_unique UNIQUE (name);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: tor_circuits tor_circuits_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tor_circuits
    ADD CONSTRAINT tor_circuits_id_unique UNIQUE (circuit_id);


--
-- Name: tor_circuits tor_circuits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tor_circuits
    ADD CONSTRAINT tor_circuits_pkey PRIMARY KEY (id);


--
-- Name: order_tasks uq_order_task_sequence; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_tasks
    ADD CONSTRAINT uq_order_task_sequence UNIQUE (order_id, sequence_number);


--
-- Name: refund_events uq_refund_event_task; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refund_events
    ADD CONSTRAINT uq_refund_event_task UNIQUE (task_id);


--
-- Name: order_tasks uq_task_idempotency_token; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_tasks
    ADD CONSTRAINT uq_task_idempotency_token UNIQUE (idempotency_token);


--
-- Name: users users_api_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_api_key_unique UNIQUE (api_key);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_referral_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_referral_code_unique UNIQUE (referral_code);


--
-- Name: idx_balance_tx_external; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_balance_tx_external ON public.balance_transactions USING btree (external_tx_id) WHERE (external_tx_id IS NOT NULL);


--
-- Name: idx_balance_tx_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_balance_tx_order ON public.balance_transactions USING btree (order_id) WHERE (order_id IS NOT NULL);


--
-- Name: idx_balance_tx_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_balance_tx_timestamp ON public.balance_transactions USING btree ("timestamp");


--
-- Name: idx_balance_tx_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_balance_tx_type ON public.balance_transactions USING btree (type);


--
-- Name: idx_balance_tx_user_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_balance_tx_user_time ON public.balance_transactions USING btree (user_id, "timestamp" DESC);


--
-- Name: idx_device_nodes_available; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_nodes_available ON public.device_nodes USING btree (device_type, status, active_sessions) WHERE ((status)::text = 'ACTIVE'::text);


--
-- Name: idx_device_nodes_country; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_nodes_country ON public.device_nodes USING btree (country);


--
-- Name: idx_device_nodes_type_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_nodes_type_status ON public.device_nodes USING btree (device_type, status);


--
-- Name: idx_invariant_log_failed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invariant_log_failed ON public.invariant_check_log USING btree (passed) WHERE (passed = false);


--
-- Name: idx_invariant_log_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invariant_log_timestamp ON public.invariant_check_log USING btree (check_timestamp DESC);


--
-- Name: idx_order_tasks_executing_started; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_order_tasks_executing_started ON public.order_tasks USING btree (execution_started_at) WHERE ((status)::text = 'EXECUTING'::text);


--
-- Name: idx_order_tasks_failed_permanent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_order_tasks_failed_permanent ON public.order_tasks USING btree (created_at DESC) WHERE ((status)::text = 'FAILED_PERMANENT'::text);


--
-- Name: idx_order_tasks_order_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_order_tasks_order_status ON public.order_tasks USING btree (order_id, status);


--
-- Name: idx_order_tasks_pending_scheduled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_order_tasks_pending_scheduled ON public.order_tasks USING btree (scheduled_at) WHERE ((status)::text = 'PENDING'::text);


--
-- Name: idx_order_tasks_retrying; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_order_tasks_retrying ON public.order_tasks USING btree (retry_after) WHERE ((status)::text = 'FAILED_RETRYING'::text);


--
-- Name: idx_order_tasks_unrefunded_failed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_order_tasks_unrefunded_failed ON public.order_tasks USING btree (order_id) WHERE (((status)::text = 'FAILED_PERMANENT'::text) AND (refunded = false));


--
-- Name: idx_order_tasks_worker_pickup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_order_tasks_worker_pickup ON public.order_tasks USING btree (status, scheduled_at, retry_after, execution_started_at);


--
-- Name: idx_orders_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_created_at ON public.orders USING btree (created_at);


--
-- Name: idx_orders_external_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_external_id ON public.orders USING btree (external_order_id) WHERE (external_order_id IS NOT NULL);


--
-- Name: idx_orders_pending_running; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_pending_running ON public.orders USING btree (status) WHERE ((status)::text = ANY ((ARRAY['PENDING'::character varying, 'RUNNING'::character varying])::text[]));


--
-- Name: idx_orders_status_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_status_created ON public.orders USING btree (status, created_at);


--
-- Name: idx_orders_target_url; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_target_url ON public.orders USING btree (target_url);


--
-- Name: idx_orders_user_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_user_created ON public.orders USING btree (user_id, created_at DESC);


--
-- Name: idx_orders_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_user_id ON public.orders USING btree (user_id);


--
-- Name: idx_orders_user_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_user_status ON public.orders USING btree (user_id, status);


--
-- Name: idx_premium_accounts_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_premium_accounts_expiry ON public.premium_accounts USING btree (premium_expiry);


--
-- Name: idx_premium_accounts_region; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_premium_accounts_region ON public.premium_accounts USING btree (region);


--
-- Name: idx_proxy_metrics_last_updated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_proxy_metrics_last_updated ON public.proxy_metrics USING btree (last_updated);


--
-- Name: idx_proxy_metrics_node; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_proxy_metrics_node ON public.proxy_metrics USING btree (proxy_node_id);


--
-- Name: idx_proxy_metrics_success_rate; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_proxy_metrics_success_rate ON public.proxy_metrics USING btree (success_rate DESC);


--
-- Name: idx_proxy_nodes_available; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_proxy_nodes_available ON public.proxy_nodes USING btree (tier, status, current_load) WHERE ((status)::text = 'ONLINE'::text);


--
-- Name: idx_proxy_nodes_country_tier; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_proxy_nodes_country_tier ON public.proxy_nodes USING btree (country, tier);


--
-- Name: idx_proxy_nodes_health_selection; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_proxy_nodes_health_selection ON public.proxy_nodes USING btree (tier, status, health_state, current_load) WHERE (((status)::text = 'ONLINE'::text) AND ((health_state)::text <> 'OFFLINE'::text));


--
-- Name: idx_proxy_nodes_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_proxy_nodes_provider ON public.proxy_nodes USING btree (provider);


--
-- Name: idx_proxy_nodes_region_tier; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_proxy_nodes_region_tier ON public.proxy_nodes USING btree (region, tier);


--
-- Name: idx_proxy_nodes_tier_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_proxy_nodes_tier_status ON public.proxy_nodes USING btree (tier, status);


--
-- Name: idx_refund_anomalies_severity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refund_anomalies_severity ON public.refund_anomalies USING btree (severity) WHERE ((resolved_at IS NULL) AND ((severity)::text = ANY ((ARRAY['WARNING'::character varying, 'CRITICAL'::character varying])::text[])));


--
-- Name: idx_refund_anomalies_unresolved; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refund_anomalies_unresolved ON public.refund_anomalies USING btree (detected_at DESC) WHERE (resolved_at IS NULL);


--
-- Name: idx_refund_events_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refund_events_created ON public.refund_events USING btree (created_at DESC);


--
-- Name: idx_refund_events_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refund_events_order ON public.refund_events USING btree (order_id);


--
-- Name: idx_refund_events_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refund_events_user ON public.refund_events USING btree (user_id);


--
-- Name: idx_services_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_services_is_active ON public.services USING btree (is_active);


--
-- Name: idx_services_sort; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_services_sort ON public.services USING btree (sort_order);


--
-- Name: idx_services_type_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_services_type_active ON public.services USING btree (service_type, is_active);


--
-- Name: idx_tasks_refund_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_refund_pending ON public.order_tasks USING btree (order_id, status, refunded) WHERE (((status)::text = 'FAILED_PERMANENT'::text) AND (refunded = false));


--
-- Name: INDEX idx_tasks_refund_pending; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.idx_tasks_refund_pending IS 'Partial index for finding unrefunded FAILED_PERMANENT tasks. Used with FOR UPDATE SKIP LOCKED.';


--
-- Name: idx_tor_circuits_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tor_circuits_active ON public.tor_circuits USING btree (status, success_rate DESC) WHERE ((status)::text = 'ACTIVE'::text);


--
-- Name: idx_tor_circuits_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tor_circuits_expires ON public.tor_circuits USING btree (expires_at);


--
-- Name: idx_tor_circuits_status_geo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tor_circuits_status_geo ON public.tor_circuits USING btree (status, exit_geo);


--
-- Name: idx_unique_idempotency_token_per_order; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_unique_idempotency_token_per_order ON public.order_tasks USING btree (order_id, idempotency_token) WHERE (idempotency_token IS NOT NULL);


--
-- Name: idx_users_api_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_api_key ON public.users USING btree (api_key) WHERE (api_key IS NOT NULL);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_referred_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_referred_by ON public.users USING btree (referred_by) WHERE (referred_by IS NOT NULL);


--
-- Name: idx_users_tier_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_tier_status ON public.users USING btree (tier, status);


--
-- Name: orders trg_orders_immutable_price; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_orders_immutable_price BEFORE UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.prevent_price_change();


--
-- Name: proxy_metrics trg_update_proxy_health_state; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_update_proxy_health_state AFTER INSERT OR UPDATE OF success_rate ON public.proxy_metrics FOR EACH ROW EXECUTE FUNCTION public.update_proxy_health_state();


--
-- Name: orders trg_verify_order_completion; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_verify_order_completion AFTER UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.verify_order_completion_invariants();


--
-- Name: services update_services_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_services_updated_at BEFORE UPDATE ON public.services FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: balance_transactions balance_tx_order_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balance_transactions
    ADD CONSTRAINT balance_tx_order_fk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: balance_transactions balance_tx_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balance_transactions
    ADD CONSTRAINT balance_tx_user_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: refund_anomalies fk_refund_anomalies_order; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refund_anomalies
    ADD CONSTRAINT fk_refund_anomalies_order FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: refund_events fk_refund_events_order; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refund_events
    ADD CONSTRAINT fk_refund_events_order FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE RESTRICT;


--
-- Name: refund_events fk_refund_events_task; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refund_events
    ADD CONSTRAINT fk_refund_events_task FOREIGN KEY (task_id) REFERENCES public.order_tasks(id) ON DELETE RESTRICT;


--
-- Name: refund_events fk_refund_events_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refund_events
    ADD CONSTRAINT fk_refund_events_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: order_tasks order_tasks_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_tasks
    ADD CONSTRAINT order_tasks_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_tasks order_tasks_proxy_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_tasks
    ADD CONSTRAINT order_tasks_proxy_node_id_fkey FOREIGN KEY (proxy_node_id) REFERENCES public.proxy_nodes(id) ON DELETE SET NULL;


--
-- Name: orders orders_service_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_service_fk FOREIGN KEY (service_id) REFERENCES public.services(id) ON DELETE RESTRICT;


--
-- Name: orders orders_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_user_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: proxy_metrics proxy_metrics_node_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proxy_metrics
    ADD CONSTRAINT proxy_metrics_node_fk FOREIGN KEY (proxy_node_id) REFERENCES public.proxy_nodes(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

